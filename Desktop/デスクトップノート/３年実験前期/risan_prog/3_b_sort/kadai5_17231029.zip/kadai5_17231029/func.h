#define MAXSTR 10000000 // WBT変換する文字列の最大長さ
#define MAXLEN 1000     // ファイルに書き込まれた1行の最大長
#define RCHECK 943620

int main(int argc, char *argv[]);
// void mysort();
int definecheck(int c_cest);

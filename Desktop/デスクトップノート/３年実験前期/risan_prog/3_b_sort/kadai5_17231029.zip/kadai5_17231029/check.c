#include "func.h"

int definecheck(int c_cest){
	int ret = 1;
	if ( RCHECK == c_cest ) {
		ret = 0;
	}
	return ret;
}


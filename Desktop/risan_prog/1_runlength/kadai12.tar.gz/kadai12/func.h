#define MAXSTR 100000000 // 文字列の最大長さ
#define MAXLEN 100000    //ファイルに書き込まれた1行の最大長
#define RCHECK C_HONEST
int runlength(unsigned char *string, int size);
int definecheck(int c_cest);
int main(int argc, char *argv[]);

#include <stdlib.h>
#include "func.h"

int runlength(unsigned char *string, int size) {
  unsigned char *ret;
  if (definecheck(C_HONEST)) {
    return 1;
  }
  // input your code here...
  
  
  return 0;
}


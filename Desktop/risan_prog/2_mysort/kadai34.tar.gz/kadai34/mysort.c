#include "func.h"

int mysort(char *string_array[], int size) {
  int ret;
  //input your code here...


  ret = definecheck(C_HONEST);
  return ret;
}

#define MAXLINE 20000000 // ファイルの行数(文字列の個数)の最大値
#define MAXLEN  200      //文字列ひとつの最大長
#define RCHECK 567710

int mysort(char *string_array[], int size);
int definecheck(int c_cest);
int main(int argc, char *argv[]);
